$( document ).ready(function() {
	var d = new Date();
	var y = d.getFullYear();
	document.getElementById("currentYear").innerHTML = y;
	// Firefox 1.0+
	var isFirefox = typeof InstallTrigger !== 'undefined';
	// Chrome 1+
	var isChrome = !!window.chrome && !!window.chrome.webstore;
	if(!isFirefox && !isChrome)
	{
		document.getElementById("pru-logo").innerHTML = '<a href="javascript:void(0);" title="Prudential Financial"><img src="assets/images/pru-logo-white.png" alt="Prudential Financial" title="Prudential Financial"></a>';
	}
	
});

window.onload = function() {
	$('.fontsLoading').removeClass('fontsLoading');
	
};

