import {ModuleWithProviders} from '@angular/core' ;
import {RouterModule,Routes} from  '@angular/router';
import {GroupComponent} from './group/group.component';
import {FooterComponent} from './footer/footer.component';
import {HeaderComponent} from './header/header.component';
import {HrmgroupComponent} from './hrmgroup/hrmgroup.component';
import {SamlinttestComponent} from './samlinttest/samlinttest.component';
import {ViewDetailsComponent} from './view-details/view-details.component';
import {UiConfiguratorComponent} from './ui-configurator/ui-configurator.component'

export const routes:Routes = [
    {path:'' , redirectTo:'group', pathMatch:'full'},
    {path:'group',component:GroupComponent},
    {path:'hrmgroup',component:HrmgroupComponent},
    {path:'ui-configurator',component:UiConfiguratorComponent}, 
    {path:'samlinttest',component:SamlinttestComponent},
    { path: 'view-details/:id', component: ViewDetailsComponent },
    
]
export const routing: ModuleWithProviders = RouterModule.forRoot(routes);