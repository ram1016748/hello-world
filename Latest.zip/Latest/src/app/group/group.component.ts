
import { Component, OnInit } from '@angular/core';
import 'rxjs/add/operator/map';
import {HttpModule, Response} from '@angular/http' ;
import {GroupService} from '../services/group.service' ;
import {DataService} from '../services/data.service' ;
import * as $ from 'jquery';

@Component({
  selector: 'app-group',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.css']
})
export class GroupComponent implements OnInit {
   homeData: any[] = [] ;
   controlNumber: any;
   companyName: any;
   public searchText:any;
  constructor(private groupService:GroupService, private dataService:DataService) { 
   }

  ngOnInit() {
    $('#desktopNavigation').addClass('hideelement');
   this.groupService.getGroupData()
    .subscribe((res)=>{
    this.homeData = res ;
    })
 
  }
  saveCtrl(argCtrlNo,argCpnName) {
    this.dataService.selectCtrlNo = argCtrlNo ;
    this.dataService.selectCompanyName = argCpnName ;
  }
}
