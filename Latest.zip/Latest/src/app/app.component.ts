import { Component, OnInit } from '@angular/core';
import { LocalStorageService } from 'angular-2-local-storage';
import * as $ from 'jquery';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';
  public lists:any;
  public localstorage:any;
  constructor (
    private localStorageService: LocalStorageService
) 
{
    this.localStorageService.set('tpaid',38);
} 
    getlocalstorage(){
      this.localstorage = this.localStorageService.get('tpaid');
    }

    ngOnInit() {
     $(".toggle-nav").click(function(){$("html, .nav-mobile").toggleClass("nav-mobile-opened")});
    }
}

