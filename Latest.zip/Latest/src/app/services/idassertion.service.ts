import { Injectable } from '@angular/core';
import {Http , Response} from '@angular/http' ;
import {Observable} from 'rxjs/Rx' ;
import 'rxjs/add/operator/map';
import {IMyDpOptions} from 'mydatepicker';
import * as moment from 'moment';
import {CoreurlService} from './coreurl.service';
//import { environment } from '../../environments/environment';

@Injectable()
export class IdassertionService {
  getUrl:any;
  constructor(private http:Http,private coreurlService:CoreurlService) {
  }
  getIdassertionData(pageCount , argCtrlNo, argFromDate, argToDate) {
    this.getUrl = this.coreurlService.serviceURL ;
   let url = this.getUrl.fetchbysearchcriteria_url+argCtrlNo+'&page='+pageCount+'&size=10';

   if(argFromDate){
     url = url+'&fromdate='+argFromDate;
   }
   if(argToDate){
     url = url+'&todate='+argToDate;
   }
   console.log('URL' + url) ;
   return this.http.get(url)
   .map((function(response:Response){
     return response.json() ;
   }))
 }

}
