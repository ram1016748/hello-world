import { Injectable } from '@angular/core';

@Injectable()
export class DataService {
  data: any ;
  selectedCtrlData: any ;
  selectedViewCtrlData:  any;
  selectedfromDate: any;
  selectedtoDate: any;
  selectedfromDateData: any;
  selectedtoDateData: any;
  selectCompanyNameData:any;
  testServiceUrlData:any;

 get serviceData() {
  return this.data ;
}
set serviceData(_data) {
   this.data = _data ;
}
get selectCtrlNo() {
  return this.selectedCtrlData ;
}
set selectCtrlNo(_data) {
   this.selectedCtrlData = _data ;
}
get selectCompanyName() {
  return this.selectCompanyNameData ;
}
set selectCompanyName(_data) {
   this.selectCompanyNameData = _data ;
}
get testServiceUrl() {
  return this.testServiceUrlData ;
}
set testServiceUrl(_data) {
   this.testServiceUrlData = _data ;
}
get fromDate() {
  return this.selectedfromDate ;
}
set fromDate(_data) {
   this.selectedfromDate = _data ;
}
get toDate() {
  return this.selectedtoDate ;
}
set toDate(_data) {
   this.selectedtoDate = _data ;
}
get selectViewCtrlNo() {
  return this.selectedViewCtrlData ;
}
set selectViewCtrlNo(_data) {
   this.selectedViewCtrlData = _data ;
}
get selectViewfromDate() {
  return this.selectedfromDateData ;
}
set selectViewfromDate(_data) {
   this.selectedfromDateData = _data ;
}
get selectViewtoDate() {
  return this.selectedtoDateData ;
}
set selectViewtoDate(_data) {
   this.selectedtoDateData = _data ;
}
  constructor() { }
}



