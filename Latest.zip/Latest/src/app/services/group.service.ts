
import { Injectable } from '@angular/core';
import { Http , Response } from '@angular/http' ;
import { Observable } from 'rxjs/Rx' ;
import 'rxjs/add/operator/map';
import { LocalStorageService } from 'angular-2-local-storage';
import { CoreurlService } from './coreurl.service';

@Injectable()
export class GroupService {
  getUrl:any;
  constructor(private http:Http, private localStorageService:LocalStorageService,private coreurlService:CoreurlService) {  
   }

  getGroupData() {
    this.getUrl = this.coreurlService.serviceURL ;
    //console.log('test URL===>' + this.getUrl.fetchtpaassociations_url);
    const url = this.getUrl.fetchtpaassociations_url+this.localStorageService.get('tpaid')+'' ;  
    return this.http.get(url)
    .map((function(response:Response){     
      return response.json() ;
    }))
  }

}
