
import { Injectable } from '@angular/core';
import { Http , Response } from '@angular/http' ;
import { Observable } from 'rxjs/Rx' ;
import 'rxjs/add/operator/map';
import { HttpHeaders } from '@angular/common/http';

@Injectable()
export class PostdataService {
   constructor(private http:Http) {}
   postData(postData: any):Observable<Response> {
      const url = 'https://localhost:9443/assertionauditservice/saveassertion';  
      console.log('in post method'+JSON.stringify(postData));
      return this.http.post(url, postData);
   }
}