
import { Injectable } from '@angular/core';
//import {environment} from '../../environments/environment';
import {UrlsService} from './urls.service';

@Injectable()
export class CoreurlService {
versionURL: any ;
  constructor(private urlsService:UrlsService) { 
    this.versionURL = this.urlsService.versionServiceURL ;
  }

  get serviceURL() {
			return {
                fetchtpaassociations_url: `${this.versionURL.fetchtpaassociations_url}tpaassociation/fetchtpaassociations?tpaid=`,
                fetchbysearchcriteria_url: `${this.versionURL.fetchbysearchcriteria_url}assertionauditservice/fetchbysearchcriteria?controlnumber=`,
                testServiceUrl:`${this.versionURL.testServiceUrl}api/v1/selfservice/idasserttest`
            }
	}

}