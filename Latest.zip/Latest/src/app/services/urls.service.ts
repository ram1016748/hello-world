
import { Injectable } from '@angular/core';
import {environment} from '../../environments/environment';

@Injectable()
export class UrlsService {
  envVersion: any = {} ;  
  constructor() {      
      this.envVersion = {
        production:false,
        development:true,
        qa:false,
        qa2:false,
        stage:false,
        stage2:false
      }    
  }
  get versionServiceURL() {
		if (this.envVersion.production) {
			return {
                fetchtpaassociations_url: 'https://48.153.19.77:9080/',
                fetchbysearchcriteria_url: 'https://localhost:9443/',
                testServiceUrl:'https://gi.prudential.com/'
            }
        } else if (this.envVersion.development) {
			return {
                fetchtpaassociations_url: 'https://48.153.18.14:9080/',
                fetchbysearchcriteria_url: 'https://localhost:9443/',
                testServiceUrl: 'https://gi-dev.prudential.com/'
            }
		} 
        else if (this.envVersion.qa) {
			return {
                fetchtpaassociations_url: 'https://48.153.16.107:9080/',
                fetchbysearchcriteria_url: 'https://localhost:9443/',
                testServiceUrl:'https://gi-qa.prudential.com/'
            }
        }
        else if (this.envVersion.qa2) {
			return {
                fetchtpaassociations_url: 'https://48.153.16.107:9080/',
              fetchbysearchcriteria_url: 'https://localhost:9443/',
            testServiceUrl:'https://gi2-qa.prudential.com/'
            }
        }
        else if (this.envVersion.stage) {
			return {
                fetchtpaassociations_url: 'https://48.153.18.14:9080/',
               fetchbysearchcriteria_url: 'https://localhost:9443/',
            testServiceUrl:'https://gi-stage.prudential.com/'
            }
        }
        else if (this.envVersion.stage2) {
			return {                
                fetchtpaassociations_url: 'https://48.153.18.14:9080/',
                fetchbysearchcriteria_url: 'https://localhost:9443/',
                testServiceUrl:'https://gi2-stage.prudential.com/'
            }
        }
		return '';
	}

}