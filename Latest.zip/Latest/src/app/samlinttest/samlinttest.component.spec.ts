import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SamlinttestComponent } from './samlinttest.component';

describe('SamlinttestComponent', () => {
  let component: SamlinttestComponent;
  let fixture: ComponentFixture<SamlinttestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SamlinttestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SamlinttestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
