import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {HttpModule, Response, Jsonp} from '@angular/http' ;
import { IdassertionService } from '../services/idassertion.service';
import * as _ from 'underscore';
import { PaginationService } from '../services/pagination.service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import {GroupService} from '../services/group.service' ;
import {DataService} from '../services/data.service' ;
import * as $ from 'jquery';
import {IMyDpOptions} from 'mydatepicker';
import * as moment from 'moment';
import {CoreurlService} from '../services/coreurl.service';


@Component({
  moduleId: module.id,
  selector: 'app-samlinttest',
  templateUrl: './samlinttest.component.html',
  styleUrls: ['./samlinttest.component.css']
})
export class SamlinttestComponent implements OnInit {
  
  myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'mm/dd/yyyy',
    openSelectorOnInputClick: true,
    indicateInvalidDate: true,
    editableDateField: false,
    openSelectorTopOfInput: true
  };
 constructor(private idassertionService:IdassertionService, private paginationService: PaginationService, 
  private groupService:GroupService, private dataservice:DataService,private coreurlService:CoreurlService) {
  }
 
    private idassertionData: any[];
    private totalPages: any;
    private totalElements: any;
    private size: any;
    private last: any;
    private number: any;
    private first: any;
    private numberOfElements: any;
    public fromDate: any;
    public toDate: any;
    private allItems: any[];
    private currenctPage : number;
    pager: any = [];
    pagedItems: any[];
    itemsPerPage : any[]; 
    homeData: any[] = [] ;
    selectCtrlNo: any ;
    showData:Boolean = false ;
    testServiceUrl : any;
    showUrl: any ;
    dateclick: any;
    public fontfamilyshead:any;
    

   ngOnInit() {
    setTimeout(()=>{
      this.testServiceUrl = this.coreurlService.serviceURL ;
      this.showUrl = this.testServiceUrl.testServiceUrl;
    },1000);

    $('#desktopNavigation').removeClass('hideelement');
     if(this.dataservice.fromDate){
       let d = this.dataservice.fromDate.split('/');
       this.fromDate = { date: { year: d[2], month: parseInt(d[0]), day: parseInt(d[1])} };
     }
     if(this.dataservice.toDate){
      let dt = this.dataservice.toDate.split('/');
      this.toDate = { date: { year: dt[2], month: parseInt(dt[0]), day: parseInt(dt[1])} };
    }
  
    this.currenctPage = 1;
    this.selectCtrlNo =  this.dataservice.selectCtrlNo ;
    this.showData = false ;
    this.groupService.getGroupData()
    .subscribe((res)=>{
    this.homeData = res ;
    })
    if( this.dataservice.selectedViewCtrlData){
      this.search(this.dataservice.selectedViewCtrlData);
      this.dataservice.selectedViewCtrlData = 0;
    }
  }
  setPage(page: number, onPageInitInd) {
    if (page < 1 || page > this.pager.totalPages) {
        return;
    }
    this.pager = this.paginationService.getPager(this.totalElements, page);
    if(!onPageInitInd){
      let getFromDate;
      let gettoDate;
      if(this.fromDate){
        getFromDate = this.fromDate.date.month+"/"+this.fromDate.date.day+"/"+this.fromDate.date.year ;
        getFromDate = moment(getFromDate).format('MM/DD/YYYY');
      }
      if(this.toDate){
        gettoDate  = this.toDate.date.month+"/"+this.toDate.date.day+"/"+this.toDate.date.year ;
        gettoDate = moment(gettoDate).format('MM/DD/YYYY');
      }
      this.idassertionService.getIdassertionData(page-1, this.selectCtrlNo, getFromDate, gettoDate)
      .subscribe((res)=>{
        this.idassertionData = res.content;  
        this.dataservice.serviceData = res.content ;
                }
            );
        }
    }
    callAssertioData(a, b, c) {
      this.idassertionService.getIdassertionData(0, a, b, c)
      .subscribe((res)=>{
      this.idassertionData = res.content;
      this.dataservice.serviceData = this.idassertionData ;
      this.totalPages = res.totalPages;
      this.totalElements = res.totalElements;
      this.size = res.size;
      this.last = res.last;
      this.number = res.number;
      this.first = res.first;
      this.numberOfElements = res.numberOfElements;
      if (this.totalElements==0) {
        document.getElementById("errMsg").innerHTML = "No records found for the given search criteria.";
        $("#errMsgDiv").removeClass("hide").focus();
        this.showData = false ;
      } else {
        // initialize to page 1
       this.setPage(1, true); 
      }
      });
    }
    search(a) {
      let x = a || this.selectCtrlNo;
      let getFromDate;
      let  gettoDate;
      let dateDiff;

      if(this.fromDate){
        getFromDate = this.fromDate.date.month+"/"+this.fromDate.date.day+"/"+this.fromDate.date.year ;
        getFromDate = moment(getFromDate).format('MM/DD/YYYY');
      }
      if(this.toDate){
        gettoDate  = this.toDate.date.month+"/"+this.toDate.date.day+"/"+this.toDate.date.year ;
        gettoDate = moment(gettoDate).format('MM/DD/YYYY');
      }
      if(gettoDate && getFromDate){
        dateDiff = moment(gettoDate).diff(getFromDate,"days") ;
      }
      if (dateDiff && dateDiff < 0) {
        document.getElementById("errMsg").innerHTML = "Please Select Valid To Date";
        $("#errMsgDiv").removeClass("hide").focus();
        this.showData = false ;
      } 
      else {
        $("#errMsgDiv").addClass("hide");
        this.showData = true ;
         this.dataservice.fromDate = getFromDate;
         this.dataservice.toDate = gettoDate;
        this.callAssertioData(x, getFromDate, gettoDate);
      }
    }
    changeCtrlNo(srno) {
      this.showData = false ;
      this.dataservice.selectCtrlNo  = srno;
      $("#errMsgDiv").addClass("hide");
    }
    forBackCtrl(data){
      this.dataservice.selectedViewCtrlData = data;
    }
}

