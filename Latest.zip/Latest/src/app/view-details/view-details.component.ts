import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {DataService} from '../services/data.service' ;
import { Location } from '@angular/common';



@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css']
})
export class ViewDetailsComponent implements OnInit {
  getId:Number ;
  getSelecteValue:any ;
  errorMessage: any ;
  payload:any ;
  keys:any;
  constructor(private route:ActivatedRoute , private dataservice:DataService, private location: Location ) { 
    
  }
  showData:Boolean ;
 
  ngOnInit() {
    this.route.params.subscribe( params => {
      this.getId = params.id ;
      let tempData = this.dataservice.serviceData ;
      let tempSelect = tempData.filter(function(value){ return value.id == params.id }) ;
      this.getSelecteValue = tempSelect[0] ;    
      this.errorMessage = JSON.parse(this.getSelecteValue.statusMessage) ; 
      this.payload = JSON.parse(this.getSelecteValue.requestPayload);
      this.keys = Object.keys(this.payload);
    })
  }
 
  back() {
    this.location.back(); 
  }
}
