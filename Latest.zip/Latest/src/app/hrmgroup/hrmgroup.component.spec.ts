import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HrmgroupComponent } from './hrmgroup.component';

describe('HrmgroupComponent', () => {
  let component: HrmgroupComponent;
  let fixture: ComponentFixture<HrmgroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HrmgroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HrmgroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
