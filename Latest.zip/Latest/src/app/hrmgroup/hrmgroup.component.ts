import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import {GroupService} from '../services/group.service' ;
import {DataService} from '../services/data.service' ;
import { LocalStorageService } from 'angular-2-local-storage';
import { Observable } from '../../../node_modules/rxjs/Observable';
import { PostdataService } from '../services/postdata.service';
import { UiConfiguratorComponent } from '../ui-configurator/ui-configurator.component';

@Component({
  selector: 'app-hrmgroup',
  templateUrl: './hrmgroup.component.html',
  styleUrls: ['./hrmgroup.component.css']
})
export class HrmgroupComponent implements OnInit {
  selectCtrlNo: any ;
  selectCompanyName: any;
  responsData:any;
  constructor(private dataservice:DataService,private localStorageService:LocalStorageService,private postdataService:PostdataService) { }
  ngOnInit() {
    $('#desktopNavigation').addClass('hideelement');
    this.selectCtrlNo =  this.dataservice.selectCtrlNo ;
    this.selectCompanyName =  this.dataservice.selectCompanyName ;
  }
  LoadSettings() {
    let selfserviceUIDesign = {};
    let selfserviceResponse = {};
    selfserviceResponse['tpaId']=this.localStorageService.get('tpaid'),
    selfserviceResponse['controNumber']=this.selectCtrlNo
    selfserviceUIDesign['selfserviceResponse'] = selfserviceResponse;  
    console.log(JSON.stringify(selfserviceUIDesign));

    this.postdataService.postData(selfserviceUIDesign)
    .map(resp => {console.log("UI Component Rombola :"+ JSON.stringify(resp.json()));
      //let responseObj = JSON.stringify(resp.json());
        })
  
    .subscribe();         
}
  }


