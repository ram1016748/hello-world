import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {routing} from './app.routes';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { GroupComponent } from './group/group.component';
import {GroupService} from './services/group.service' ;
import {HttpModule} from '@angular/http';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { FilterPipe} from './filter.pipe';
import {HrmgroupComponent} from './hrmgroup/hrmgroup.component';
import { SamlinttestComponent } from './samlinttest/samlinttest.component';
import { IdassertionService } from './services/idassertion.service';
import { PaginationService } from './services/pagination.service';
import { ViewDetailsComponent } from './view-details/view-details.component';
import { LocalStorageModule } from 'angular-2-local-storage';
import {DataService} from './services/data.service';
import { MyDatePickerModule } from 'mydatepicker';
import { UiConfiguratorComponent } from './ui-configurator/ui-configurator.component';
import { CollapsibleModule } from 'angular2-collapsible';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { ColorPickerModule } from 'ngx-color-picker';
import { FontPickerModule } from 'ngx-font-picker';
import { AnimationsComponent } from './animations/animations.component';
import { NavbarService } from './services/navbar.service';
import { CoreurlService } from '../../src/app/services/coreurl.service';
import { UrlsService } from '../../src/app/services/urls.service' ;
import { PostdataService} from './services/postdata.service';
 

@NgModule({
  declarations: [
    AppComponent, 
    GroupComponent, 
    FooterComponent,
    HeaderComponent,
    FilterPipe,
    HrmgroupComponent,
    SamlinttestComponent,
    ViewDetailsComponent,
    UiConfiguratorComponent,
    AnimationsComponent     
  ],
  imports: [
    BrowserModule,
    FormsModule,
    routing,
    HttpModule,
    AngularFontAwesomeModule,
    LocalStorageModule.withConfig({
      prefix: 'first-app',
      storageType: 'localStorage'
  }),
  MyDatePickerModule,
  CollapsibleModule,
  BrowserAnimationsModule,
  ColorPickerModule,
  FontPickerModule
  ],
  providers: [
    GroupService,
    IdassertionService,
    PaginationService,DataService,
    NavbarService,
    CoreurlService,
    UrlsService,
    PostdataService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { 
  constructor() {
 }

}
