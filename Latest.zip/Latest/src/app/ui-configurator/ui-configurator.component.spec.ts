import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UiConfiguratorComponent } from './ui-configurator.component';

describe('UiConfiguratorComponent', () => {
  let component: UiConfiguratorComponent;
  let fixture: ComponentFixture<UiConfiguratorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UiConfiguratorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UiConfiguratorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
