import { Component, OnInit } from '@angular/core';
import { CollapsibleModule } from 'angular2-collapsible';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { ColorPickerModule } from 'ngx-color-picker';
import * as $ from 'jquery';
import { fadeInAnimation } from '../animations/fadein';
import { FontPickerConfigInterface } from 'ngx-font-picker';
import {GroupService} from '../services/group.service' ;
import {DataService} from '../services/data.service' ;
import { LocalStorageService } from 'angular-2-local-storage';
import { PostdataService} from '../services/postdata.service';
import { Observable } from 'rxjs/Rx' ;
import 'rxjs/add/operator/map';
import { Response } from '@angular/http' ;
import 'rxjs/add/operator/catch';
import { Alert } from '../../../node_modules/@types/selenium-webdriver';



@Component({
  selector: 'app-ui-configurator',
  templateUrl: './ui-configurator.component.html',
  animations: [fadeInAnimation],
  host: { '[@fadeInAnimation]': '' },
  styleUrls: ['./ui-configurator.component.css']
})
export class UiConfiguratorComponent implements OnInit {
  public color: string = "#000000";
  public bodytext: string = "#000000";
  public background: string = "#ffffff";
  public footercolor:string = "#ebebeb"
  public headercolor:string = "#07639d"
  public fontfamilys:any;
  public fontfamilyshead:any;
  defaultfont:string;
  headerfont:string;
  selectCtrlNo: any;
  selectCompanyName: any;
  public options: any;
  public options1: any;
  public myStyles: any;
  savesettings: any;
  success: any;
  failed: any;
  public   cssRequest :any;
  responsData:any;

  constructor(private dataservice:DataService,private localStorageService:LocalStorageService,private postdataService:PostdataService) {
  }
  ngOnInit() {
    
    $('#desktopNavigation').removeClass('hideelement');
    this.selectCtrlNo =  this.dataservice.selectCtrlNo ;
    this.selectCompanyName =  this.dataservice.selectCompanyName ;

    this.defaultfont = "Arial";
    this.fontfamilys = [];
    this.fontfamilys.push({'title':'Arial','value':'Arial'});
    this.fontfamilys.push({'title':'Georgia','value':'Georgia, serif'});
    this.fontfamilys.push({'title':'Times New Roman','value':'Times New Roman'});
    this.fontfamilys.push({'title':'Palatino Linotype','value':'Palatino Linotype'});
    
    this.headerfont = "sans-serif";
    this.fontfamilyshead = [];
    this.fontfamilyshead.push({'title':'Arial','value':'Arial'});
    this.fontfamilyshead.push({'title':'Georgia','value':'Georgia, serif'});
    this.fontfamilyshead.push({'title':'Times New Roman','value':'Times New Roman'});
    this.fontfamilyshead.push({'title':'Palatino Linotype','value':'Palatino Linotype'});
    this.fontfamilyshead.push({'title':'sans-serif','value':'sans-serif'});
    this.fontfamilyshead.push({'title':'Verdana','value':'Verdana, sans-serif'});
    this.fontfamilyshead.push({'title':'Helvetica','value':'Helvetica, sans-serif'});
    this.fontfamilyshead.push({'title':'Courier','value':'Courier, monospace'});

  }
  onChange(fon,callfrom){
    if(callfrom == 'first'){
      this.defaultfont = fon;
    }
    if(callfrom == 'second'){
      this.headerfont = fon;
    }
  }
  saveSettings() {
    let savesettings={};
    let fontColor={};
    let fontFamily={};
    let backgroundColor={};
    let headerFooterColor={};
    let headerFooterDisplay={}
    
    if (this.options === undefined) {
      this.options = true;
    }
    if (this.options1 === undefined) {
      this.options1 = true;
    }
    
    fontColor['color']=this.color,
    fontColor['bodytext']=this.bodytext,
    backgroundColor['background']=this.background,
    headerFooterColor['footercolor']=this.footercolor,
    headerFooterColor['headercolor']=this.headercolor,
    fontFamily['defaultfont'] = this.defaultfont,
    fontFamily['headerfont'] = this.headerfont,
    headerFooterDisplay['options'] = this.options,
    headerFooterDisplay['options1'] = this.options1,
    savesettings['controNumber']=this.selectCtrlNo,
    savesettings['tpaId']=this.localStorageService.get('tpaid')

    var uiConfig = {};
    let success = {};
    let failed = {};
    uiConfig["fontColor"] = {'header':this.color, 'default':this.bodytext};
    uiConfig["fontFamily"] = {'header':this.headerfont, 'default':this.defaultfont};
    uiConfig["backgroundColor"] = {'background':this.background};
    uiConfig["headerFooterDisplay"] = {'header':this.options, 'default':this.options1};
    
    var selfserviceUIDesign = {};
    selfserviceUIDesign['tpaId']=this.localStorageService.get('tpaid'),
    selfserviceUIDesign['controNumber']=this.selectCtrlNo,
    selfserviceUIDesign['uiConfig'] = {'uiConfig' : uiConfig};
    
      this.cssRequest['selfserviceUIDesign'] = {'selfserviceUIDesign' : selfserviceUIDesign}  
      this.getRequestData(this.cssRequest);
      //console.log(JSON.stringify(cssRequest));
      this.postdataService.postData(this.cssRequest)
      .map(resp => {console.log("UI Component Rom :"+ JSON.stringify(resp.json()));
      let responseObj = JSON.stringify(resp.json());
      this.success = {"transaction" : "Success"};
        //console.log(this.success.transaction);
       // alert(JSON.stringify(this.success.transaction));
      })
      .catch(error => {
        console.error(error);
        this.failed = {"transaction" : "Failure"};
        //console.log(this.failed);
        //alert(JSON.stringify(this.failed.transaction));
        return Observable.throw(error.json().error || 'Server error');
      })
      .subscribe();    
  }
  public getRequestData(object:any):Object{
    return object(object) ;
  }
  LoadSettings() {
  this.responsData = {
    "selfserviceUIDesign": {
      "controNumber": "0016000",
      "tpaId" : "11",
      "uiConfig": {
        "fontColor": {
          "header": "#000000",
          "default": "#000000"
        },
        "fontFamily": {
          "header": "sans-serif",
          "default": "Arial"
        },
        "backgroundColor": {
          "background": "#000000"
        },
        "headerFooterColor": {
          "header": "#000000",
          "footer": "#000000"
        },
        "headerFooterDisplay": {
          "header": "ON",
          "footer": "OFF"
        }
      }
    }
  };
  }

}
